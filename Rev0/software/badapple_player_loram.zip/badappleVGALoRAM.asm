;display Bad Apple file on VGA monitor
;program resides in low 64K RAM whereas VGA memory is at high 64K RAM
;  need to use putHiRAM system call to reach VGA memory
VGAbase	equ 0c000h
VGAfont	equ 0cc00h
;;; CF interface registers, Simple80 mapping
CFdata   	equ 090h    	;CF data register
CFerr    	equ 091h    	;CF error reg
CFsectcnt equ 092h    	;CF sector count reg
CF07     	equ 093h   	;CF LA0-7
CF815    	equ 094h       	;CF LA8-15
CF1623   	equ 095h       	;CF LA16-23
CF2427   	equ 096h       	;CF LA24-27
CFstat   	equ 097h       	;CF status/command reg

putHiRAM	equ 0ff03h	;remember regC is altered

	org 1000h
	jp start
error:	db 0
offset:	db 0
track	ds 2
sector	ds 1
VGArow	ds 2
start:
	ld sp,1000h	
	di
	xor a
	ld (error),a	;clear error flag
;initialize graphic font character
	ld de,VGAfont
	ld hl,graphicFont
initG:
	ld a,(hl)
	call putHiRAM
	inc de
	inc hl
	ld a,e		;load 128 bytes
	cp 128
	jr nz,initG
;BadApple image is stored in CF disk starting from 
; track $C0, sector $20
	xor a
	ld (track+1),a
	ld a,0c0h
	ld (track),a
	ld a,01fh
	ld (sector),a

spinn:
	ld de,VGAbase		;point to beginning of video memory
	call nxtSectImg		;first 1/3 of image
	call nxtSectImg		;2/3 of image
	call nxtSectImg		;3/3 of image
	call delay		;adjust for 20 frames/sec
	jp spinn

delay:
;delay for a while
	push de
	ld de,1600h		;delay
inner:
	dec e
	jp z,delay1
	jr inner
delay1:
	dec d
	jp z,delay2
	jr inner
delay2:	
	pop de
	ret
nxtSectImg:
;fetch next image from CF disk
;image stored starts from track 0xC0, sector 0x20
;3 sectors per image (1.5K bytes)
;regDE points to the image memory
	push bc
	ld a,(sector)	;get sector value
	inc a
	jr nz,nxtImage1
	push af
	ld a,(track)
	inc a
	ld (track),a
	pop af
nxtImage1:
	ld (sector),a	;save updated sector
	out (CF07),a	; write LSB CF LA address
	ld a,1		; read one sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,(track)	; get LSB track address
	out (CF815),a	; write to CF LA register
	ld a,(track+1)	; get MSB track address
	out (CF1623),a	; write to CF LA register, MSB
	ld a,20h		; read CF sector command
	out (CFstat),a	; issue the CF read sector comand
	call readdrq	; check drq bit set before read CF data

Do1Sector:
	ld e,0c0h		;initialize cursor to leftmost position of 4th line of block-of-4
BO4:
;read two bytes from CF.  Convert it to appropriate font
;two consecutive bytes forms vertical 4 block-of-4-pixel with most significant 2 bits of 
; 2 bytes as the 4th (bottom) BO4 and least significant 2 bits of the 2 bytes as 1st (top)
; BO4.  Two bits from each byte is extracted to form 4-bit value and presented as font values
;  0-$f.  The font converts back to the corresponding BO4 pixel patterns.
;  This is how the B&W image were converted to data with "image2cpp" application
;   B&W image is converted to byte using "Vertical-1 bit per pixel" mode
	in a,(CFdata)	;get two bytes into reg H, L
	ld h,a
	in a,(CFdata)
	ld l,a
;process the 4th line of block-of-4
;Most significant two bits of reg H and most significant 2 bits of reg L are 4th line of block-of-4
	xor a
	rlc h
	rla
	rlc h
	rla
	rlc l
	rla
	rlc l
	rla		;reg A now contains the 4 pixel info
	call putHiRAM	;write 4-pixel data to video memory pointed by reg DE
;	ld (de),a		;write the 4-pixel data to calculated location of VGA display
; calculate the 4-pixel data for 3rd line of block-of-4
	xor a
	rlc h
	rla
	rlc h
	rla
	rlc l
	rla
	rlc l
	rla		;reg A ow contains the 4-pixel info for 3rd line
	res 6,e		;reg B points to 3rd line of block-of-4
	call putHiRAM	;write 4-pixel data to video memory pointed by reg DE
;	ld (de),a		;write out the 4-pixel data
;calculate the 4-pixel data for 2nd line of block-of-4
	xor a
	rlc h
	rla
	rlc h
	rla
	rlc l
	rla
	rlc l
	rla		;reg A ow contains the 4-pixel info for 3rd line
	res 7,e
	set 6,e		;reg B points to 2nd line of block-of-4
	call putHiRAM	;write 4-pixel data to video memory pointed by reg DE
;	ld (de),a		;write out the 4-pixel data
;calculate the 4-pixel data for 1st line of block-of-4
	xor a
	rlc h
	rla
	rlc h
	rla
	rlc l
	rla
	rlc l
	rla		;reg A ow contains the 4-pixel info for 3rd line
	res 6,e		;reg B points to 2nd line of block-of-4
	call putHiRAM	;write 4-pixel data to video memory pointed by reg DE
;	ld (de),a		;write out the 4-pixel data
	set 6,e
	set 7,e
	inc e
	jp nz,BO4
	inc d		;next 4 lines
	ld a,d
	and 3		;check for $C400, $C800, $CC00 for end of 512byte record
	jp nz,Do1Sector
;finish reading CF sector of 512 byte of data
	pop bc
	ret
readdrq:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq
	ret

graphicFont:
	db 0,0,0,0,0,0,0,0
	db 0fh,0fh,0fh,0fh,0,0,0,0			;one pixel, lower right
	db 0,0,0,0,0fh,0fh,0fh,0fh			;one pixel, upper right
	db 0fh,0fh,0fh,0fh,0fh,0fh,0fh,0fh		;two pixels, right side
	db 0f0h,0f0h,0f0h,0f0h,0,0,0,0		;one pixel, lower left
	db 0ffh,0ffh,0ffh,0ffh,0,0,0,0		;two pixels, lower half
	db 0f0h,0f0h,0f0h,0f0h,0fh,0fh,0fh,0fh		;two pixels, diagnal
	db 0ffh,0ffh,0ffh,0ffh,0fh,0fh,0fh,0fh		;three pixels
	db 0,0,0,0,0f0h,0f0h,0f0h,0f0h		;one pixel upper left
	db 0fh,0fh,0fh,0fh,0f0h,0f0h,0f0h,0f0h		;two pixels diagnal
	db 0,0,0,0,0ffh,0ffh,0ffh,0ffh		;two pixels, upper half
	db 0fh,0fh,0fh,0fh,0ffh,0ffh,0ffh,0ffh		;3 pixels
	db 0f0h,0f0h,0f0h,0f0h,0f0h,0f0h,0f0h,0f0h	;2 pixel, left half
	db 0ffh,0ffh,0ffh,0ffh,0f0h,0f0h,0f0h,0f0h	; 3 pixels
	db 0f0h,0f0h,0f0h,0f0h,0ffh,0ffh,0ffh,0ffh	;3 pixels
	db 0ffh,0ffh,0ffh,0ffh,0ffh,0ffh,0ffh,0ffh	;4 pixels



