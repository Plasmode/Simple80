;display Bad Apple file on VGA monitor
VGAbase	equ 0c000h
VGAfont	equ 0cc00h
;;; CF interface registers, Simple80 mapping
CFdata   	equ 090h    	;CF data register
CFerr    	equ 091h    	;CF error reg
CFsectcnt equ 092h    	;CF sector count reg
CF07     	equ 093h   	;CF LA0-7
CF815    	equ 094h       	;CF LA8-15
CF1623   	equ 095h       	;CF LA16-23
CF2427   	equ 096h       	;CF LA24-27
CFstat   	equ 097h       	;CF status/command reg

	org 1000h
	jp start
error:	db 0
offset:	db 0
track	ds 2
sector	ds 1
VGArow	ds 2
start:
	ld sp,1000h	
	di
	xor a
	ld (error),a	;clear error flag
;clear screen
	ld hl,VGAbase
clrVid:
	xor a
	ld (hl),a
	inc hl
	ld a,h
	cp 0cch
	jr nz,clrVid
;initialize font
	ld de,VGAfont
	ld hl,TFont	;font table
	ld bc,400h	;1K font table
	ldir
;initialize graphic font character
	ld de,VGAfont
	ld hl,graphicFont
	ld bc,128		;16 permutation of 2x2 blocks
	ldir

	xor a
	ld (track+1),a
	ld a,0c0h
	ld (track),a
	ld a,01fh
	ld (sector),a

spinn:
;	ld a,VGAbase
;	ld (VGArow),a
	ld hl,VGAbase		;point to beginning of video memory
	call nxtSectImg		;first 1/3 of image


	jr spinn1			;skip over diagnostic message
;write caption to first line
	push bc
	push hl
	ld b,0			;first line
;	ld c,VGAbase
	ld hl,Caption
Caption1:
	ld a,(hl)
	cp 0
	jr z,endCaption
	out (c),a
	inc b
	inc hl
	jr Caption1
endCaption:
	ld b,64			;second line
	ld hl,Track_Sect
trackSect1:
	ld a,(hl)
	cp 0
	jr z,endTS
	out (c),a
	inc b
	inc hl
	jr trackSect1
endTS:
	ld a,(track)
	call HEXOUT
	ld a,(HexHi)		;display track value, high nibble
	out (c),a
	inc b
	ld a,(HexLo)		;display track value, low nibble
	out (c),a
	inc b
	ld a,':'			;track/sector separator
	out (c),a
	inc b
	ld a,(sector)
	call HEXOUT
	ld a,(HexHi)		;display sector value
	out (c),a
	inc b
	ld a,(HexLo)
	out (c),a
	pop hl
	pop bc

spinn1:
;	ld a,VGAbase+4		
;	ld (VGArow),a
	call nxtSectImg		;2/3 of image
;	ld a,VGAbase+8
;	ld (VGArow),a
	call nxtSectImg		;3/3 of image
	call delay

	jp spinn


HEXOUT: 	
	PUSH BC
        	LD B,A
        	RRCA
        	RRCA
        	RRCA
        	RRCA
        	AND 0Fh
        	CALL HEXASC
        	ld (HexHi),a		;save to local variable
        	LD A,B
        	AND 0Fh
        	CALL HEXASC
        	ld (HexLo),a		;save to local variable
        	POP BC
        	RET
HEXASC:
;convert nibble to ASCII 	
	ADD 90h
        	DAA
        	ADC A,40h
        	DAA
        	RET
HexHi:	ds 1
HexLo:	ds 1
delay:
;delay for a while
	push de
	ld de,1600h		;delay
inner:
	dec e
	jp z,delay1
	jr inner
delay1:
	dec d
	jp z,delay2
	jr inner
delay2:	
	pop de
	ret
nxtSectImg:
;fetch next image from CF disk
;image stored starts from track 0xC0, sector 0x20
;3 sectors per image (1.5K bytes)
;regHL points to the image memory
;the variable "VGArow" is the base row of the image
	push bc
	push de
	ld a,(sector)	;get sector value
	inc a
	jr nz,nxtImage1
	push af
	ld a,(track)
	inc a
	ld (track),a
	pop af
nxtImage1:
	ld (sector),a	;save updated sector
	out (CF07),a	; write LSB CF LA address
	ld a,1		; read one sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,(track)	; get LSB track address
	out (CF815),a	; write to CF LA register
	ld a,(track+1)	; get MSB track address
	out (CF1623),a	; write to CF LA register, MSB
	ld a,20h		; read CF sector command
	out (CFstat),a	; issue the CF read sector comand
	call readdrq	; check drq bit set before read CF data

;;	ld a,(VGArow)	;start from first block-of-4

;;	ld c,a
Do1Sector:
;;	ld b,0c0h		;initialize cursor to leftmost position of 4th line of block-of-4
	ld l,0c0h		;initialize cursor to leftmost position of 4th line of block-of-4
BO4:
;read two bytes from CF.  Convert it to appropriate font
;two consecutive bytes forms vertical 4 block-of-4-pixel with most significant 2 bits of 
; 2 bytes as the 4th (bottom) BO4 and least significant 2 bits of the 2 bytes as 1st (top)
; BO4.  Two bits from each byte is extracted to form 4-bit value and presented as font values
;  0-$f.  The font converts back to the corresponding BO4 pixel patterns.
;  This is how the B&W image were converted to data with "image2cpp" application
;   B&W image is converted to byte using "Vertical-1 bit per pixel" mode
	in a,(CFdata)	;get two bytes into reg D, E
	ld d,a
	in a,(CFdata)
	ld e,a
;process the 4th line of block-of-4
;Most significant two bits of reg D and most significant 2 bits of reg E are 4th line of block-of-4
	xor a
	rlc d
	rla
	rlc d
	rla
	rlc e
	rla
	rlc e
	rla		;reg A now contains the 4 pixel info
;	out (c),a		;write the 4-pixel data to calculated location of VGA display
	ld (hl),a		;write the 4-pixel data to calculated location of VGA display
; calculate the 4-pixel data for 3rd line of block-of-4
	xor a
	rlc d
	rla
	rlc d
	rla
	rlc e
	rla
	rlc e
	rla		;reg A ow contains the 4-pixel info for 3rd line
;	res 6,b		;reg B points to 3rd line of block-of-4
	res 6,l		;reg B points to 3rd line of block-of-4
;	out (c),a		;write out the 4-pixel data
	ld (hl),a		;write out the 4-pixel data
;calculate the 4-pixel data for 2nd line of block-of-4
	xor a
	rlc d
	rla
	rlc d
	rla
	rlc e
	rla
	rlc e
	rla		;reg A ow contains the 4-pixel info for 3rd line
;	res 7,b
;	set 6,b		;reg B points to 2nd line of block-of-4
;	out (c),a		;write out the 4-pixel data
	res 7,l
	set 6,l		;reg B points to 2nd line of block-of-4
	ld (hl),a		;write out the 4-pixel data
;calculate the 4-pixel data for 1st line of block-of-4
	xor a
	rlc d
	rla
	rlc d
	rla
	rlc e
	rla
	rlc e
	rla		;reg A ow contains the 4-pixel info for 3rd line
;	res 6,b		;reg B points to 2nd line of block-of-4
;	out (c),a		;write out the 4-pixel data
	res 6,l		;reg B points to 2nd line of block-of-4
	ld (hl),a		;write out the 4-pixel data
;	set 6,b
;	set 7,b
;	inc b
	set 6,l
	set 7,l
	inc l
	jp nz,BO4
;	inc c
;	ld a,c
;	and 3
	inc h		;next 4 lines
	ld a,h
	and 3		;check for $C400, $C800, $CC00 for end of 512byte record
	jp nz,Do1Sector
;finish reading CF sector of 512 byte of data
	pop de
	pop bc
	ret
readdrq:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq
	ret
Caption:
	db "BadAppleVGA Rev 0.1",0
Track_Sect:
	db "Track:Sector ",0
graphicFont:
	db 0,0,0,0,0,0,0,0
	db 0fh,0fh,0fh,0fh,0,0,0,0			;one pixel, lower right
	db 0,0,0,0,0fh,0fh,0fh,0fh			;one pixel, upper right
	db 0fh,0fh,0fh,0fh,0fh,0fh,0fh,0fh		;two pixels, right side
	db 0f0h,0f0h,0f0h,0f0h,0,0,0,0		;one pixel, lower left
	db 0ffh,0ffh,0ffh,0ffh,0,0,0,0		;two pixels, lower half
	db 0f0h,0f0h,0f0h,0f0h,0fh,0fh,0fh,0fh		;two pixels, diagnal
	db 0ffh,0ffh,0ffh,0ffh,0fh,0fh,0fh,0fh		;three pixels
	db 0,0,0,0,0f0h,0f0h,0f0h,0f0h		;one pixel upper left
	db 0fh,0fh,0fh,0fh,0f0h,0f0h,0f0h,0f0h		;two pixels diagnal
	db 0,0,0,0,0ffh,0ffh,0ffh,0ffh		;two pixels, upper half
	db 0fh,0fh,0fh,0fh,0ffh,0ffh,0ffh,0ffh		;3 pixels
	db 0f0h,0f0h,0f0h,0f0h,0f0h,0f0h,0f0h,0f0h	;2 pixel, left half
	db 0ffh,0ffh,0ffh,0ffh,0f0h,0f0h,0f0h,0f0h	; 3 pixels
	db 0f0h,0f0h,0f0h,0f0h,0ffh,0ffh,0ffh,0ffh	;3 pixels
	db 0ffh,0ffh,0ffh,0ffh,0ffh,0ffh,0ffh,0ffh	;4 pixels

TFont:
     db 00h,000h,000h,000h,000h,000h,000h,000h,07Eh,081h,0A5h,081h,0A5h,099h,081h,07Eh
     db 3Ch,07Eh,0DBh,0FFh,0C3h,07Eh,03Ch,000h,000h,06Ch,0FEh,0FEh,07Ch,038h,010h,000h
     db 10h,038h,07Ch,0FEh,07Ch,038h,010h,000h,000h,03Ch,018h,0FFh,0FFh,008h,018h,000h
     db 10h,038h,07Ch,0FEh,0FEh,010h,038h,000h,000h,000h,018h,03Ch,018h,000h,000h,000h
     db 0FFh,0FFh,0E7h,0C3h,0E7h,0FFh,0FFh,0FFh,000h,03Ch,042h,081h,081h,042h,03Ch,000h
     db 0FFh,0C3h,0BDh,07Eh,07Eh,0BDh,0C3h,0FFh,01Fh,007h,00Dh,07Ch,0C6h,0C6h,07Ch,000h
     db 00h,07Eh,0C3h,0C3h,07Eh,018h,07Eh,018h,004h,006h,007h,004h,004h,0FCh,0F8h,000h
     db 0Ch,00Ah,00Dh,00Bh,0F9h,0F9h,01Fh,01Fh,000h,092h,07Ch,06Ch,0C6h,06Ch,07Ch,092h
     db 00h,000h,060h,078h,07Eh,078h,060h,000h,000h,000h,006h,01Eh,07Eh,01Eh,006h,000h
     db 18h,07Eh,018h,018h,018h,018h,07Eh,018h,024h,024h,024h,024h,024h,000h,024h,000h
     db 0FFh,0B6h,076h,036h,036h,036h,036h,000h,07Eh,0C1h,0DCh,022h,022h,01Fh,083h,07Eh
     db 00h,000h,000h,07Eh,07Eh,000h,000h,000h,018h,07Eh,018h,018h,07Eh,018h,000h,0FFh
     db 08h,01Ch,008h,008h,008h,008h,008h,000h,008h,008h,008h,008h,008h,01Ch,008h,000h
     db 00h,000h,002h,0FFh,002h,000h,000h,000h,000h,000h,040h,0FFh,040h,000h,000h,000h
     db 00h,000h,000h,0C0h,0C0h,0C0h,0FFh,000h,000h,024h,066h,0FFh,066h,024h,000h,000h
     db 00h,000h,010h,038h,07Ch,0FEh,000h,000h,000h,000h,000h,0FEh,07Ch,038h,010h,000h
     
 db 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 010h, 038h, 038h, 010h, 010h, 000h, 010h, 000h
 db 06Ch, 06Ch, 048h, 000h, 000h, 000h, 000h, 000h, 000h, 028h, 07Ch, 028h, 028h, 07Ch, 028h, 000h
 db 020h, 038h, 040h, 030h, 008h, 070h, 010h, 000h, 064h, 064h, 008h, 010h, 020h, 04Ch, 04Ch, 000h
 db 020h, 050h, 050h, 020h, 054h, 048h, 034h, 000h, 030h, 030h, 020h, 000h, 000h, 000h, 000h, 000h
 db 010h, 020h, 020h, 020h, 020h, 020h, 010h, 000h, 020h, 010h, 010h, 010h, 010h, 010h, 020h, 000h
 db 000h, 028h, 038h, 07Ch, 038h, 028h, 000h, 000h, 000h, 010h, 010h, 07Ch, 010h, 010h, 000h, 000h
 db 000h, 000h, 000h, 000h, 000h, 030h, 030h, 020h, 000h, 000h, 000h, 07Ch, 000h, 000h, 000h, 000h
 db 000h, 000h, 000h, 000h, 000h, 030h, 030h, 000h, 000h, 004h, 008h, 010h, 020h, 040h, 000h, 000h
 db 038h, 044h, 04Ch, 054h, 064h, 044h, 038h, 000h, 010h, 030h, 010h, 010h, 010h, 010h, 038h, 000h
 db 038h, 044h, 004h, 018h, 020h, 040h, 07Ch, 000h, 038h, 044h, 004h, 038h, 004h, 044h, 038h, 000h
 db 008h, 018h, 028h, 048h, 07Ch, 008h, 008h, 000h, 07Ch, 040h, 040h, 078h, 004h, 044h, 038h, 000h
 db 018h, 020h, 040h, 078h, 044h, 044h, 038h, 000h, 07Ch, 004h, 008h, 010h, 020h, 020h, 020h, 000h
 db 038h, 044h, 044h, 038h, 044h, 044h, 038h, 000h, 038h, 044h, 044h, 03Ch, 004h, 008h, 030h, 000h
 db 000h, 000h, 030h, 030h, 000h, 030h, 030h, 000h, 000h, 000h, 030h, 030h, 000h, 030h, 030h, 020h
 db 004h, 008h, 010h, 020h, 010h, 008h, 004h, 000h, 000h, 000h, 07Ch, 000h, 000h, 07Ch, 000h, 000h
 db 020h, 010h, 008h, 004h, 008h, 010h, 020h, 000h, 038h, 044h, 004h, 018h, 010h, 000h, 010h, 000h
;upper case
 db 038h, 044h, 05Ch, 054h, 05Ch, 040h, 038h, 000h, 038h, 044h, 044h, 044h, 07Ch, 044h, 044h, 000h
 db 078h, 044h, 044h, 078h, 044h, 044h, 078h, 000h, 038h, 044h, 040h, 040h, 040h, 044h, 038h, 000h
 db 078h, 044h, 044h, 044h, 044h, 044h, 078h, 000h, 07Ch, 040h, 040h, 078h, 040h, 040h, 07Ch, 000h
 db 07Ch, 040h, 040h, 078h, 040h, 040h, 040h, 000h, 038h, 044h, 040h, 05Ch, 044h, 044h, 03Ch, 000h
 db 044h, 044h, 044h, 07Ch, 044h, 044h, 044h, 000h, 038h, 010h, 010h, 010h, 010h, 010h, 038h, 000h
 db 004h, 004h, 004h, 004h, 044h, 044h, 038h, 000h, 044h, 048h, 050h, 060h, 050h, 048h, 044h, 000h
 db 040h, 040h, 040h, 040h, 040h, 040h, 07Ch, 000h, 044h, 06Ch, 054h, 044h, 044h, 044h, 044h, 000h
 db 044h, 064h, 054h, 04Ch, 044h, 044h, 044h, 000h, 038h, 044h, 044h, 044h, 044h, 044h, 038h, 000h
 db 078h, 044h, 044h, 078h, 040h, 040h, 040h, 000h, 038h, 044h, 044h, 044h, 054h, 048h, 034h, 000h
 db 078h, 044h, 044h, 078h, 048h, 044h, 044h, 000h, 038h, 044h, 040h, 038h, 004h, 044h, 038h, 000h
 db 07Ch, 010h, 010h, 010h, 010h, 010h, 010h, 000h, 044h, 044h, 044h, 044h, 044h, 044h, 038h, 000h
 db 044h, 044h, 044h, 044h, 044h, 028h, 010h, 000h, 044h, 044h, 054h, 054h, 054h, 054h, 028h, 000h
 db 044h, 044h, 028h, 010h, 028h, 044h, 044h, 000h, 044h, 044h, 044h, 028h, 010h, 010h, 010h, 000h
 db 078h, 008h, 010h, 020h, 040h, 040h, 078h, 000h, 038h, 020h, 020h, 020h, 020h, 020h, 038h, 000h
 db 000h, 040h, 020h, 010h, 008h, 004h, 000h, 000h, 038h, 008h, 008h, 008h, 008h, 008h, 038h, 000h
 db 010h, 028h, 044h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 0FFh
;lower case
 db 030h, 030h, 010h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 038h, 004h, 03Ch, 044h, 03Ch, 000h
 db 040h, 040h, 078h, 044h, 044h, 044h, 078h, 000h, 000h, 000h, 038h, 044h, 040h, 044h, 038h, 000h
 db 004h, 004h, 03Ch, 044h, 044h, 044h, 03Ch, 000h, 000h, 000h, 038h, 044h, 078h, 040h, 038h, 000h
 db 018h, 020h, 020h, 078h, 020h, 020h, 020h, 000h, 000h, 000h, 03Ch, 044h, 044h, 03Ch, 004h, 038h
 db 040h, 040h, 070h, 048h, 048h, 048h, 048h, 000h, 010h, 000h, 010h, 010h, 010h, 010h, 018h, 000h
 db 008h, 000h, 018h, 008h, 008h, 008h, 048h, 030h, 040h, 040h, 048h, 050h, 060h, 050h, 048h, 000h
 db 010h, 010h, 010h, 010h, 010h, 010h, 018h, 000h, 000h, 000h, 068h, 054h, 054h, 044h, 044h, 000h
 db 000h, 000h, 070h, 048h, 048h, 048h, 048h, 000h, 000h, 000h, 038h, 044h, 044h, 044h, 038h, 000h
 db 000h, 000h, 078h, 044h, 044h, 044h, 078h, 040h, 000h, 000h, 03Ch, 044h, 044h, 044h, 03Ch, 004h
 db 000h, 000h, 058h, 024h, 020h, 020h, 070h, 000h, 000h, 000h, 038h, 040h, 038h, 004h, 038h, 000h
 db 000h, 020h, 078h, 020h, 020h, 028h, 010h, 000h, 000h, 000h, 048h, 048h, 048h, 058h, 028h, 000h
 db 000h, 000h, 044h, 044h, 044h, 028h, 010h, 000h, 000h, 000h, 044h, 044h, 054h, 07Ch, 028h, 000h
 db 000h, 000h, 048h, 048h, 030h, 048h, 048h, 000h, 000h, 000h, 048h, 048h, 048h, 038h, 010h, 060h
 db 000h, 000h, 078h, 008h, 030h, 040h, 078h, 000h, 018h, 020h, 020h, 060h, 020h, 020h, 018h, 000h
 db 010h, 010h, 010h, 000h, 010h, 010h, 010h, 000h, 030h, 008h, 008h, 00Ch, 008h, 008h, 030h, 000h
 db 028h, 050h, 000h, 000h, 000h, 000h, 000h, 000h, 010h, 038h, 06Ch, 044h, 044h, 07Ch, 000h, 000h



