;1/13/23
;copy font and text data to upper RAM using "put" system call

SIOAData	equ 0		;location of SIO chan A data
SIOACmd	equ 1		;location of SIO A command/status reg
SIOBData	equ 2		;location of SIO chan B data
SIOBCmd	equ 3		;location of SIO B command/status reg
CFdata   	equ 90h    	;CF data register
CFerr    	equ 91h    	;CF error reg
CFsectcnt equ 92h    	;CF sector count reg
CF07     	equ 93h   	;CF LA0-7
CF815    	equ 94h       	;CF LA8-15
CF1623   	equ 95h       	;CF LA16-23
CF2427   	equ 96h       	;CF LA24-27
CFstat   	equ 97h       	;CF status/command reg

putHiRAM	equ 0ff03h	;remember regC is altered
getHiRAM	equ 0ff00h	;remember regC is altered

	org 1000h
	ld sp,1000h	;stack below this program
;clear video RAM
	ld de,0c000h	;beginning of video RAM & Font	
clrVid:
	xor a
	call putHiRAM
	inc de
	ld a,d		;check for top of video memory
	cp 0cch
	jr nz,clrVid
;install the font
	ld de,0cc00h	;beginning of video font memory	
	ld hl,TFont
putFont:
	ld a,(hl)
	call putHiRAM	;regA and reg C are altered
	inc de
	inc hl
	ld a,0d0h
	cp d		;top of font memory?
	jr nz,putFont
;write the banner
	ld de,0c000h
	ld hl,banner
putVid:
	ld a,(hl)
	or a
	jr z,nxtLine
	call putHiRAM
	inc de
	inc hl
	ld a,d
	cp 0cch		;top of video RAM?
	jr nz,putVid
	jp 0b403h		;return to monitor
nxtLine:
;point to first character of next line
	inc hl		;skip over the null terminator
	ld a,(hl)		;if two consecutive null terminators, exit
	or a		;check for null terminator
	jp z,0b403
	ld a,11000000b	;mask off lower 6-bit
	and e
	add a,40h
	ld e,a
	jp nc,putVid	;next block-of-4 lines if carry set
nxtB04:
	inc d
	ld a,0cch		;top of video RAM
	cp d
	jp z,0b403h	;return to monitor
	jp putVid

;Larger font, more readible
TFont:
     db 00h,000h,000h,000h,000h,000h,000h,000h,07Eh,081h,0A5h,081h,0A5h,099h,081h,07Eh
     db 3Ch,07Eh,0DBh,0FFh,0C3h,07Eh,03Ch,000h,000h,06Ch,0FEh,0FEh,07Ch,038h,010h,000h
     db 10h,038h,07Ch,0FEh,07Ch,038h,010h,000h,000h,03Ch,018h,0FFh,0FFh,008h,018h,000h
     db 10h,038h,07Ch,0FEh,0FEh,010h,038h,000h,000h,000h,018h,03Ch,018h,000h,000h,000h
     db 0FFh,0FFh,0E7h,0C3h,0E7h,0FFh,0FFh,0FFh,000h,03Ch,042h,081h,081h,042h,03Ch,000h
     db 0FFh,0C3h,0BDh,07Eh,07Eh,0BDh,0C3h,0FFh,01Fh,007h,00Dh,07Ch,0C6h,0C6h,07Ch,000h
     db 00h,07Eh,0C3h,0C3h,07Eh,018h,07Eh,018h,004h,006h,007h,004h,004h,0FCh,0F8h,000h
     db 0Ch,00Ah,00Dh,00Bh,0F9h,0F9h,01Fh,01Fh,000h,092h,07Ch,06Ch,0C6h,06Ch,07Ch,092h
     db 00h,000h,060h,078h,07Eh,078h,060h,000h,000h,000h,006h,01Eh,07Eh,01Eh,006h,000h
     db 18h,07Eh,018h,018h,018h,018h,07Eh,018h,024h,024h,024h,024h,024h,000h,024h,000h
     db 0FFh,0B6h,076h,036h,036h,036h,036h,000h,07Eh,0C1h,0DCh,022h,022h,01Fh,083h,07Eh
     db 00h,000h,000h,07Eh,07Eh,000h,000h,000h,018h,07Eh,018h,018h,07Eh,018h,000h,0FFh
     db 08h,01Ch,008h,008h,008h,008h,008h,000h,008h,008h,008h,008h,008h,01Ch,008h,000h
     db 00h,000h,002h,0FFh,002h,000h,000h,000h,000h,000h,040h,0FFh,040h,000h,000h,000h
     db 00h,000h,000h,0C0h,0C0h,0C0h,0FFh,000h,000h,024h,066h,0FFh,066h,024h,000h,000h
     db 00h,000h,010h,038h,07Ch,0FEh,000h,000h,000h,000h,000h,0FEh,07Ch,038h,010h,000h
     
 db 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 010h, 038h, 038h, 010h, 010h, 000h, 010h, 000h
 db 06Ch, 06Ch, 048h, 000h, 000h, 000h, 000h, 000h, 000h, 028h, 07Ch, 028h, 028h, 07Ch, 028h, 000h
 db 020h, 038h, 040h, 030h, 008h, 070h, 010h, 000h, 064h, 064h, 008h, 010h, 020h, 04Ch, 04Ch, 000h
 db 020h, 050h, 050h, 020h, 054h, 048h, 034h, 000h, 030h, 030h, 020h, 000h, 000h, 000h, 000h, 000h
 db 010h, 020h, 020h, 020h, 020h, 020h, 010h, 000h, 020h, 010h, 010h, 010h, 010h, 010h, 020h, 000h
 db 000h, 028h, 038h, 07Ch, 038h, 028h, 000h, 000h, 000h, 010h, 010h, 07Ch, 010h, 010h, 000h, 000h
 db 000h, 000h, 000h, 000h, 000h, 030h, 030h, 020h, 000h, 000h, 000h, 07Ch, 000h, 000h, 000h, 000h
 db 000h, 000h, 000h, 000h, 000h, 030h, 030h, 000h, 000h, 004h, 008h, 010h, 020h, 040h, 000h, 000h
 db 038h, 044h, 04Ch, 054h, 064h, 044h, 038h, 000h, 010h, 030h, 010h, 010h, 010h, 010h, 038h, 000h
 db 038h, 044h, 004h, 018h, 020h, 040h, 07Ch, 000h, 038h, 044h, 004h, 038h, 004h, 044h, 038h, 000h
 db 008h, 018h, 028h, 048h, 07Ch, 008h, 008h, 000h, 07Ch, 040h, 040h, 078h, 004h, 044h, 038h, 000h
 db 018h, 020h, 040h, 078h, 044h, 044h, 038h, 000h, 07Ch, 004h, 008h, 010h, 020h, 020h, 020h, 000h
 db 038h, 044h, 044h, 038h, 044h, 044h, 038h, 000h, 038h, 044h, 044h, 03Ch, 004h, 008h, 030h, 000h
 db 000h, 000h, 030h, 030h, 000h, 030h, 030h, 000h, 000h, 000h, 030h, 030h, 000h, 030h, 030h, 020h
 db 004h, 008h, 010h, 020h, 010h, 008h, 004h, 000h, 000h, 000h, 07Ch, 000h, 000h, 07Ch, 000h, 000h
 db 020h, 010h, 008h, 004h, 008h, 010h, 020h, 000h, 038h, 044h, 004h, 018h, 010h, 000h, 010h, 000h
;upper case
 db 038h, 044h, 05Ch, 054h, 05Ch, 040h, 038h, 000h, 038h, 044h, 044h, 044h, 07Ch, 044h, 044h, 000h
 db 078h, 044h, 044h, 078h, 044h, 044h, 078h, 000h, 038h, 044h, 040h, 040h, 040h, 044h, 038h, 000h
 db 078h, 044h, 044h, 044h, 044h, 044h, 078h, 000h, 07Ch, 040h, 040h, 078h, 040h, 040h, 07Ch, 000h
 db 07Ch, 040h, 040h, 078h, 040h, 040h, 040h, 000h, 038h, 044h, 040h, 05Ch, 044h, 044h, 03Ch, 000h
 db 044h, 044h, 044h, 07Ch, 044h, 044h, 044h, 000h, 038h, 010h, 010h, 010h, 010h, 010h, 038h, 000h
 db 004h, 004h, 004h, 004h, 044h, 044h, 038h, 000h, 044h, 048h, 050h, 060h, 050h, 048h, 044h, 000h
 db 040h, 040h, 040h, 040h, 040h, 040h, 07Ch, 000h, 044h, 06Ch, 054h, 044h, 044h, 044h, 044h, 000h
 db 044h, 064h, 054h, 04Ch, 044h, 044h, 044h, 000h, 038h, 044h, 044h, 044h, 044h, 044h, 038h, 000h
 db 078h, 044h, 044h, 078h, 040h, 040h, 040h, 000h, 038h, 044h, 044h, 044h, 054h, 048h, 034h, 000h
 db 078h, 044h, 044h, 078h, 048h, 044h, 044h, 000h, 038h, 044h, 040h, 038h, 004h, 044h, 038h, 000h
 db 07Ch, 010h, 010h, 010h, 010h, 010h, 010h, 000h, 044h, 044h, 044h, 044h, 044h, 044h, 038h, 000h
 db 044h, 044h, 044h, 044h, 044h, 028h, 010h, 000h, 044h, 044h, 054h, 054h, 054h, 054h, 028h, 000h
 db 044h, 044h, 028h, 010h, 028h, 044h, 044h, 000h, 044h, 044h, 044h, 028h, 010h, 010h, 010h, 000h
 db 078h, 008h, 010h, 020h, 040h, 040h, 078h, 000h, 038h, 020h, 020h, 020h, 020h, 020h, 038h, 000h
 db 000h, 040h, 020h, 010h, 008h, 004h, 000h, 000h, 038h, 008h, 008h, 008h, 008h, 008h, 038h, 000h
 db 010h, 028h, 044h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 0FFh
;lower case
 db 030h, 030h, 010h, 000h, 000h, 000h, 000h, 000h, 000h, 000h, 038h, 004h, 03Ch, 044h, 03Ch, 000h
 db 040h, 040h, 078h, 044h, 044h, 044h, 078h, 000h, 000h, 000h, 038h, 044h, 040h, 044h, 038h, 000h
 db 004h, 004h, 03Ch, 044h, 044h, 044h, 03Ch, 000h, 000h, 000h, 038h, 044h, 078h, 040h, 038h, 000h
 db 018h, 020h, 020h, 078h, 020h, 020h, 020h, 000h, 000h, 000h, 03Ch, 044h, 044h, 03Ch, 004h, 038h
 db 040h, 040h, 070h, 048h, 048h, 048h, 048h, 000h, 010h, 000h, 010h, 010h, 010h, 010h, 018h, 000h
 db 008h, 000h, 018h, 008h, 008h, 008h, 048h, 030h, 040h, 040h, 048h, 050h, 060h, 050h, 048h, 000h
 db 010h, 010h, 010h, 010h, 010h, 010h, 018h, 000h, 000h, 000h, 068h, 054h, 054h, 044h, 044h, 000h
 db 000h, 000h, 070h, 048h, 048h, 048h, 048h, 000h, 000h, 000h, 038h, 044h, 044h, 044h, 038h, 000h
 db 000h, 000h, 078h, 044h, 044h, 044h, 078h, 040h, 000h, 000h, 03Ch, 044h, 044h, 044h, 03Ch, 004h
 db 000h, 000h, 058h, 024h, 020h, 020h, 070h, 000h, 000h, 000h, 038h, 040h, 038h, 004h, 038h, 000h
 db 000h, 020h, 078h, 020h, 020h, 028h, 010h, 000h, 000h, 000h, 048h, 048h, 048h, 058h, 028h, 000h
 db 000h, 000h, 044h, 044h, 044h, 028h, 010h, 000h, 000h, 000h, 044h, 044h, 054h, 07Ch, 028h, 000h
 db 000h, 000h, 048h, 048h, 030h, 048h, 048h, 000h, 000h, 000h, 048h, 048h, 048h, 038h, 010h, 060h
 db 000h, 000h, 078h, 008h, 030h, 040h, 078h, 000h, 018h, 020h, 020h, 060h, 020h, 020h, 018h, 000h
 db 010h, 010h, 010h, 000h, 010h, 010h, 010h, 000h, 030h, 008h, 008h, 00Ch, 008h, 008h, 030h, 000h
 db 028h, 050h, 000h, 000h, 000h, 000h, 000h, 000h, 010h, 038h, 06Ch, 044h, 044h, 07Ch, 000h, 000h

banner:
	db "1234567890123456789012345678901234567890123456789012345678901234"
	db "2",0
	db "3   640 X 480 MONOCHROME DISPLAY FOR RC2014",0
	db "4",0
	db "5   48 LINES OF TEXT  TEXT SIZE IS 8X8 PIXELS",0
	db "6   64 Characters per line",0
	db "7   4KX8 DUAL PORT RAM, 25 MHZ OSCILLATOR, EPM7128SQC100 CPLD",0
	db "8     1K Font lookup table",0
	db "9     3K Display memory",0
	db "10  Font can be dynamically loaded",0
	db "11  Display memory can be updated at anytime",0
	db "12  Display memory are accessible at $1C000-$1CBFF",0
	db "13  Font memory is accessible at $1CC00-$1CFFF",0
	db "14  PS 2 Keyboard is in planning  ",0
	db "15    ",0
	db "16    !@#$%^&*()_+~`[]\;',./-={}|:<>?",0
	db "17      ",0
	db "18 ",1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,0
	db "19      ",0
	db "20     ",0
	db "21     ",0
	db "22     ",0
	db "23     ",0
	db "24     ",0
	db "25  ",0
	db "26  ",0
	db "27  H     H   EEEEEEE   L         L           OOO     ",0
	db "28  H     H   E         L         L          O   O   ",0
	db "29  H     H   E         L         L         o     o  ",0
	db "30  HHHHHHH   EEEEEE    L         L         o     o  ",0
	db "31  H     H   E         L         L         o     o  ",0
	db "32  H     H   E         L         L          O   O   ",0
	db "33  H     H   EEEEEEE   LLLLLLL   LLLLLLL     OOO     ",0
	db "34  ",0
	db "35",0
	db "36",0
	db "37",0


	db "38   W           W      OOO     RRRRRR   L         DDDDD  ",0
	db "39   W           W     O   O    R     R  L         D    D ",0
	db "40   W     W     W    o     o   R     R  L         D     D ",0
	db "41    W   W W   W     o     o   RRRRRR   L         D     D",0
	db "42    W   W W   W     o     o   R  R     L         D     D",0
	db "43     W W   W W       O   O    R   R    L         D    D ",0
	db "44      W     W         OOO     R     R  LLLLLLL   DDDDD  ",0
	db "45",0
	db "46",0
	db "47 abcdefghijklmnopqrstuvwxyz",0
	db "48 THIS IS THE LAST LINE, ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",0,0

	end


	jp getHiRAM
putHiRAM:
;put regA into high RAM pointed by (DE)
	ld c,a		;save regA
	ld a,11h		;Wr0 points to reg1 + reset ex st int
	out (SIOBCmd),a
	ld a,40h		;Wr1 No Tx interrupts, set READY high
	out (SIOBCmd),a
	ld a,c
	ld (de),a
	ld a,11h		;Wr0 points to reg 1 + reset ex st int
	out (SIOBCmd),a
	ld a,0		;Wr1 No Tx interrupts, set READY low
	out (SIOBCmd),a
	ret 
getHiRAM:
;get high RAM pointed by (DE) into regA
	ld a,11h		;Wr0 points to reg1 + reset ex st int
	out (SIOBCmd),a
	ld a,40h		;Wr1 No Tx interrupts, set READY high
	out (SIOBCmd),a
	ld a,(de)
	ld c,a
	ld a,11h		;Wr0 points to reg 1 + reset ex st int
	out (SIOBCmd),a
	ld a,0		;Wr1 No Tx interrupts, set READY low
	out (SIOBCmd),a
	ld a,c
	ret

	end
